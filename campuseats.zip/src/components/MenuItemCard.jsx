function MenuItemCard({ item, onAdd, onView }) {
  return (
    <article
      className="card menu-card"
      onClick={() => {
        onView?.(item)
      }}
    >
      <div className="thumb" aria-hidden="true">{item.name.charAt(0)}</div>
      <p className="tag">{item.category}</p>
      <h3>{item.name}</h3>
      <p className="muted">{item.description}</p>
      <p className="price">RM {item.price.toFixed(2)}</p>
      <button
        className="btn"
        disabled={!item.available}
        onClick={(e) => {
          e.stopPropagation()   // don't count "Add to cart" as a view
          onAdd(item)
        }}
      >
        {item.available ? 'Add to cart' : 'Sold out'}
      </button>
    </article>
  )
}
export default MenuItemCard